# Calculator
A simple and ready to use calculator application for android devices.

A very simple and easy to learn Android application idea for beginner developers.
